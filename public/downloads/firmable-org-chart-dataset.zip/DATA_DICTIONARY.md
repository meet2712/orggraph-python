# Dataset dictionary

## `companies.csv`

| Column | Meaning |
|---|---|
| `company_id` | Stable synthetic company key. |
| `company_name` | Synthetic company name. |
| `industry` | Industry used to vary the department mix. |
| `size_band` | Small, Growth, or Mid-market. |
| `employee_count` | Generated headcount. |
| `headquarters` | Synthetic headquarters location. |

## `employees_messy.csv`

This is the inference input. It intentionally contains inconsistent formatting, abbreviations, misspellings, sentinels, and missing values.

| Column | Meaning |
|---|---|
| `employee_id` | Stable employee key. |
| `company_id` | Employee's company. |
| `full_name` | Synthetic name. |
| `job_title` | Noisy title; can be blank. |
| `department` | Noisy, aliased, conflicting, or missing department. |
| `team` | Noisy, inconsistently cased, conflicting, or missing team label. |
| `location` | Location; can be missing. |
| `work_email` | Synthetic `.example` address, never a real contact. |

## `employees_ground_truth.csv`

This file is hidden from production inference and used for training/evaluation.

| Column | Meaning |
|---|---|
| `employee_id` | Stable employee key. |
| `company_id` | Employee's company. |
| `full_name` | Synthetic name. |
| `canonical_title` | Clean generated title. |
| `canonical_department` | True department. |
| `canonical_team` | True generated team used only for training and evaluation. |
| `canonical_level` | True seniority level. |
| `manager_employee_id` | True direct manager; blank only for the CEO/root. |
| `is_people_manager` | `1` when the employee has direct reports. |
| `noise_profile` | Messiness applied to the input title, retained only for segmented evaluation. |

## `reporting_edges.csv`

| Column | Meaning |
|---|---|
| `company_id` | Company key. |
| `employee_id` | Direct report. |
| `manager_employee_id` | True direct manager. |

